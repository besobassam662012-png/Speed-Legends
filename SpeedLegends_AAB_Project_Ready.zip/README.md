# Speed Legends — AAB build

1. Install Android Studio.
2. Open this project folder in Android Studio.
3. Let Gradle sync and install Android SDK 36 if Android Studio asks.
4. Build > Generate Signed Bundle / APK.
5. Choose Android App Bundle.
6. Create a new upload key/keystore if you do not already have one.
7. Build the release `.aab`.
8. Keep the keystore and passwords safe; you need them for future updates.

Google Play currently requires new apps to target Android 16 / API 36.
